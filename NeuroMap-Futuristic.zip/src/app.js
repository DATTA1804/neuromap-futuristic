let selectedNode=null;

const width=window.innerWidth-320;
const height=window.innerHeight-60;

const svg=d3.select("#mindmap")
  .attr("width",width)
  .attr("height",height)
  .call(d3.zoom().on("zoom",e=>g.attr("transform",e.transform)));

const g=svg.append("g").attr("transform","translate(80,80)");

d3.json("./public/data.json").then(data=>{
  root=d3.hierarchy(data);
  tree=d3.tree().size([height-160,width-200]);
  update(root);
});

function update(root){
  tree(root);

  const links=g.selectAll("path")
    .data(root.links(),d=>d.target.data.name);

  links.enter()
    .append("path")
    .merge(links)
    .attr("fill","none")
    .attr("stroke","#334155")
    .attr("stroke-width",2)
    .attr("d",d3.linkHorizontal()
      .x(d=>d.y)
      .y(d=>d.x)
    );

  const nodes=g.selectAll("circle")
    .data(root.descendants(),d=>d.data.name);

  nodes.enter()
    .append("circle")
    .attr("r",18)
    .attr("fill","#2563eb")
    .attr("cx",d=>d.y)
    .attr("cy",d=>d.x)
    .on("click",(e,d)=>selectNode(d))
    .append("title")
    .text(d=>d.data.description||"");

  nodes
    .attr("cx",d=>d.y)
    .attr("cy",d=>d.x);
}

function selectNode(d){
  selectedNode=d;
  document.getElementById("panel-title").innerText=d.data.name;
  document.getElementById("panel-desc").value=d.data.description||"";
}

function saveNode(){
  if(selectedNode){
    selectedNode.data.description=document.getElementById("panel-desc").value;
  }
}

function expandAll(){}
function collapseAll(){}
function fitView(){
  svg.transition().duration(750)
    .call(d3.zoom().transform,d3.zoomIdentity);
}
